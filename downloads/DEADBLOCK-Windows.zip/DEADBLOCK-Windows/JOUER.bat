@echo off
setlocal
cd /d "%~dp0"
title DEADBLOCK - Gardez cette fenetre ouverte
if not exist "runtime\node.exe" (
  echo Extrayez tout le ZIP avant de lancer JOUER.
  pause
  exit /b 1
)
if not exist "app\dist\index.html" (
  echo Le dossier du jeu est incomplet. Extrayez a nouveau tout le ZIP.
  pause
  exit /b 1
)
"%~dp0runtime\node.exe" "%~dp0app\scripts\play.mjs"
if errorlevel 1 (
  echo.
  echo Le jeu n'a pas pu demarrer. Le message ci-dessus indique la cause.
  pause
  exit /b 1
)
